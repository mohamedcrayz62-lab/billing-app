# بناء تطبيق APK

هذا المشروع مجهز للبناء عبر GitHub Actions دون الحاجة إلى تثبيت Flutter على جهازك.

1. أنشئ مستودعاً جديداً على GitHub.
2. ارفع محتويات هذا المجلد إلى المستودع (اجعل `pubspec.yaml` في الجذر).
3. افتح تبويب **Actions** في المستودع.
4. شغّل سير العمل **Build Android APK** عبر **Run workflow**، أو ادفع commit إلى `main`.
5. بعد نجاح البناء، افتح نتيجة التشغيل (workflow run) ونزّل الملف من **Artifacts** باسم `billing-app-release-apk`.
6. فك ضغط ملف Artifact، ثم ثبّت `app-release.apk` على هاتف Android.

ملاحظة: ملف APK الناتج موقّع بمفتاح debug وفق إعداد Gradle الحالي، وهو مناسب للتجربة والتثبيت المباشر، وليس للنشر التجاري على Google Play. للنشر التجاري يجب إنشاء مفتاح توقيع release خاص وحفظه بأمان.
